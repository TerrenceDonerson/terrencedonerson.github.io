//
//  LEANIcons.h
//  GoNativeIOS
//
//  Created by Weiyin He on 9/19/14.
//  Copyright (c) 2014 GoNative.io LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LEANIcons : NSObject
+ (UIImage*)imageForIconIdentifier:(NSString*)string size:(CGFloat)size;
@end
