// Action Creator
export function addPerson(person) {
    return {
        type: 'ADD_PERSON',
        data: person
    }
}

