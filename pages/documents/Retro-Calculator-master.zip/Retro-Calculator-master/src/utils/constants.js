export const keypadKeys = [
  ['c', '%', 'Del', '/'],
  ['7', '8', '9', '*'],
  ['4', '5', '6', '-'],
  ['1', '2', '3', '+'],
  ['0','x^2','√', '.','='],
]

export const operators = ['*', '-', '+', '/', '='];
export const specialOperators = ['c', '%', 'Del'];